<template>
  <div>
    <h4>Opssssss.. Page not found</h4>
    <p>
      Click
      <router-link to="/">-Here-</router-link>to go back to the home page
    </p>
  </div>
</template>

<style scoped>
h4,
p,
a {
  color: #fff;
}
</style>