<template>
  <div>
    <div class="result-container">
      <div v-if="currentType" class="content">
        <h4 class="question_title title-effect">
          <span>나의 아동권리참여 성향은</span>
          <h2>{{ currentType.type_summary }}</h2>
        </h4>
        <img :src="imageSrc" :alt="currentType.type" />
        <h4 class="feature">{{ currentType.feature }}</h4>
        <p class="comment">{{ currentType.comment }}</p>
        <div class="buttons">
          <router-link class="button" to="/">테스트 다시하기</router-link>
        </div>

        <div class="icon_content">
          <div class="box">
            <a href="#"><img src="../../assets/facebook_icon.png"/></a>
          </div>
          <div class="box">
            <a href="#"><img src="../../assets/kakao_icon.png"/></a>
          </div>
          <div class="box">
            <a href="#"><img src="../../assets/instar_icon.png"/></a>
          </div>
          <div class="box">
            <a href="#"><img src="../../assets/twiter_icon.png"/></a>
          </div>
          <div class="box">
            <a href="#"><img src="../../assets/kakao_plus_icon.png"/></a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {mapGetters} from "vuex";
import types from "../../resource/types";

export default {
  props: ["type"],
  data() {
    return {
      types: types,
      showWrongAnswer: false,
    };
  },
  computed: {
    ...mapGetters(["numCorrect", "numTotal", "answers"]),
    score() {
      return this.numCorrect === 0
        ? 0
        : (this.numCorrect / this.numTotal) * 100;
    },
    currentType() {
      return this.types.find((item) => {
        return item.type.toUpperCase() === this.type.toUpperCase();
      });
    },
    imageSrc() {
      return "/src/assets/character_" + this.type.toLowerCase() + ".png";
    },
  },
  mounted() {
    if (!this.currentType) {
      this.$router.push("/");
    }
  },
  methods: {},
};
</script>

<style scoped>
.result-container {
  padding: 40px;
}

.question_title {
  font-size: 24px;
  line-height: 1.2;
  margin: 0px 0px 32px 0px;
}

.question_title span {
}

.question_title h2 {
  font-size: 28px;
  font-weight: normal;
  margin: 10px 0 0 1px;
}
.feature {
  font-size: 24px;
  letter-spacing: -0.04em;
  margin: 20px 0px 0px 0px;
}
.comment {
  color: #282828;
  margin: 10px 0px;
  font-size: 20px;
  line-height: 1.5;
  font-weight: 400;
}

.result-container p span {
  font-weight: bolder;
}

.buttons {
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100%;
  border: none !important;
  justify-content: center;
  align-items: center;
}

.buttons .button {
  margin-top: 40px;
  width: 100%;
  height: 80px;
  line-height: 80px;
  text-decoration: none;
  text-align: center;
  color: #fff;
  background-color: #082a5a;
  font-size: 24px;
  border-radius: 40px;
}

.button:hover {
  background: #a7aac9;
}

.icon_content {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 28px;
}
.icon_content .box {
  text-align: center;
  padding: 8px;
  line-height: 1;
}

.icon_content .box img {
  width: 48px;
}
</style>
